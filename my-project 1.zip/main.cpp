#include <iostream>
#include <fstream>
#include <cstdlib> // Для функції exit()

// Максимальна кількість чисел для зчитування
const int MAX_NUMBERS = 10;
// Ім'я вхідного файлу
const std::string FILE_NAME = "number.txt";

void calculate_sum_of_multiples_of_3() {
    
    // 1. Ініціалізація змінних
    int number;
    int sum_multiples_of_3 = 0;
    int numbers_read = 0;

    // 2. Відкриття файлу
    // std::ifstream - клас для вхідного файлового потоку (читання)
    std::ifstream inputFile(FILE_NAME);

    // 3. Перевірка, чи файл відкрито успішно
    if (!inputFile.is_open()) {
        std::cerr << "❌ Помилка: Не вдалося відкрити файл " << FILE_NAME << "!" << std::endl;
        std::cerr << "Переконайтеся, що файл існує в тій самій директорії, що і програма." << std::endl;
        return; // Вихід з функції
    }

    // 4. Цикл зчитування та обробки даних
    std::cout << "🔍 Аналіз даних з файлу " << FILE_NAME << "..." << std::endl;
    std::cout << "========================================" << std::endl;
    
    // Цикл триває, поки ми можемо зчитувати цілі числа та не досягли ліміту
    while (numbers_read < MAX_NUMBERS && inputFile >> number) {
        
        // Перевірка умови: чи число кратне 3? (Залишок від ділення дорівнює 0)
        if (number % 3 == 0) {
            // Умова істинна: додаємо число до суми
            sum_multiples_of_3 += number;
            std::cout << "✅ Знайдено кратне 3: " << number << " (Сума: " << sum_multiples_of_3 << ")" << std::endl;
        } else {
            // Умова хибна: ігноруємо число
            std::cout << "  - Пропущено число: " << number << std::endl;
        }
        
        // Інкремент лічильника зчитаних чисел
        numbers_read++;
    }

    // 5. Закриття файлу
    inputFile.close();

    // Перевірка, чи було зчитано 10 чисел (якщо ні, це може бути помилка у файлі)
    if (numbers_read < MAX_NUMBERS) {
        std::cout << "⚠️ Попередження: Зчитано лише " << numbers_read << " чисел замість 10." << std::endl;
    }

    // 6. Виведення кінцевого результату
    std::cout << "========================================" << std::endl;
    std::cout << "✅ Фінальний результат:" << std::endl;
    std::cout << "Сума чисел, кратних 3, становить: " << sum_multiples_of_3 << std::endl;
}

int main() {
    calculate_sum_of_multiples_of_3();
    return 0;
}
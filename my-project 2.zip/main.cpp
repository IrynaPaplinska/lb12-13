#include <iostream>
#include <fstream>     // Для роботи з файлами (std::ifstream)
#include <iomanip>     // Для форматування виводу
#include <string>

using namespace std;

// Оголошення констант розміру матриці та імені файлу
const int ROWS = 4;
const int COLS = 4;
// !!! ПЕРЕВІРТЕ: Файл "matrix_data.txt" має лежати поруч із програмою !!!
const string FILE_NAME = "matrix_data.txt"; 

void process_matrix_from_file() {
    
    // Оголошення матриці дійсних чисел 4x4 та змінних
    double A[ROWS][COLS];
    double sum_negative = 0.0;
    int i, j;
    
    // --- ЕТАП 1: Зчитування матриці з файлу ---
    
    ifstream inputFile(FILE_NAME);

    cout << "--- Зчитування елементів матриці з файлу " << FILE_NAME << " ---" << endl;

    if (!inputFile.is_open()) {
        cerr << "❌ ПОМИЛКА: Не вдалося відкрити файл " << FILE_NAME << "!" << endl;
        cerr << "Переконайтеся, що файл існує в тій самій директорії, що і програма." << endl;
        return;
    }

    // Вкладені цикли для зчитування 4x4 елементів
    bool read_success = true;
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            // Зчитування елемента. Якщо зчитування невдале (наприклад, кінець файлу), виходимо.
            if (!(inputFile >> A[i][j])) {
                cerr << "❌ ПОМИЛКА: Недостатньо даних (потрібно 16 чисел) або некоректний формат у файлі." << endl;
                read_success = false;
                break; 
            }
        }
        if (!read_success) break; 
    }

    inputFile.close(); // Закриваємо файл

    if (!read_success) {
        return; // Завершуємо роботу, якщо зчитування було невдалим
    }

    // --- ЕТАП 2: Виведення зчитаної матриці (для контролю) ---
    cout << "\n--- Зчитана матриця A (4x4) ---" << endl;
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            cout << fixed << setprecision(2) << setw(8) << A[i][j] << " ";
        }
        cout << endl;
    }

    // --- ЕТАП 3: Обчислення суми ---
    cout << "\n--- Обчислення суми від'ємних елементів у непарних рядках ---" << endl;

    for (i = 0; i < ROWS; i++) {
        // Умова 1: Перевірка, чи рядок є НЕПАРНИМ (індекси 0, 2 відповідають рядкам 1, 3)
        if (i % 2 == 0) { 
            cout << "Рядок " << i + 1 << " (непарний): ";
            
            for (j = 0; j < COLS; j++) {
                // Умова 2: Перевірка, чи елемент є ВІД'ЄМНИМ
                if (A[i][j] < 0) {
                    // Накопичення суми
                    sum_negative += A[i][j];
                    cout << "[" << fixed << setprecision(2) << A[i][j] << "] "; // Діагностика
                }
            }
            cout << endl;
        } else {
            // Діагностика: Пропускаємо парні рядки (2-й та 4-й)
            cout << "Рядок " << i + 1 << " (парний): Пропущено." << endl;
        }
    }

    // --- ЕТАП 4: Виведення кінцевого результату ---
    cout << "\n------------------------------------------------------------" << endl;
    cout << "✅ Загальна сума від'ємних елементів у непарних рядках: "
         << fixed << setprecision(2) << sum_negative << endl;
    cout << "------------------------------------------------------------" << endl;
}

int main() {
    process_matrix_from_file();
    return 0;
}